/** @type import('hardhat/config').HardhatUserConfig */

require("dotenv").config();
require("@nomiclabs/hardhat-ethers");
const { API_URL, PRIVATE_KEY } = process.env;

module.exports = {
  solidity: "0.8.18",
  defaultNetwork: "goerli",
  networks: {
    // ganache: {
    //   url: API_URL,
    //   accounts: [
    //     `8297e8d5921be0a0b8198e0ebe397908a0e36210e5654597cf257a568b777e92`,
    //   ],
    // },
    hardhat: {},
    goerli: {
      url: API_URL,
      accounts: [`0x${PRIVATE_KEY}`],
    },
  },
};
