const validStartDate = Math.floor(Date.parse("2023-01-07") / 1000); // Convert date string to Unix timestamp
const validEndDate = Math.floor(Date.parse("2023-04-14") / 1000); // Convert date string to Unix timestamp

async function main() {
  const MerceNFT1 = await ethers.getContractFactory("MerceNFT1");

  // Start deployment, returning a promise that resolves to a contract object
  const myNFT = await MerceNFT1.deploy(validStartDate, validEndDate);
  await myNFT.deployed();
  console.log("MerceNFT1 Contract deployed to address:", myNFT.address);
  console.log("MerceNFT1 contract valid start date:", validStartDate);
  console.log("MerceNFT1 contract valid end date:", validEndDate);
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
