require("dotenv").config();
// const API_URL = process.env.API_URL;

//settings for goerli
const API_URL =
  "https://eth-goerli.g.alchemy.com/v2/wR-F2H3s29xwPrUxBQlfTGuNFp771_qs";
const PUBLIC_KEY = "0xa3277306462F05eBaB9AaC6BbFcB928c385576e7";
const PRIVATE_KEY =
  "f8f39c4f04c0353cd3e73335c69ce8eb00bb2f004ce342963f4ecd12abb51255";

const { createAlchemyWeb3 } = require("@alch/alchemy-web3");
const web3 = createAlchemyWeb3(API_URL);

const contract = require("../artifacts/contracts/MerceNFT1.sol/MerceNFT1.json");

//  interact with created NFT smart contract , proide deployed contract id here
const contractAddress = "0xf2c7770bcacaf79c54c5f0172748fb547af221d9";
const nftContract = new web3.eth.Contract(contract.abi, contractAddress);

async function mintNFT(tokenURI) {
  const nonce = await web3.eth.getTransactionCount(PUBLIC_KEY, "latest"); //get latest nonce

  //the transaction
  const tx = {
    from: PUBLIC_KEY,
    to: contractAddress,
    nonce: nonce,
    gas: 500000,
    data: nftContract.methods.mintNFT(PUBLIC_KEY, tokenURI).encodeABI(),
  };

  // console.log("retrieved data from mintNft");
  // console.log(tx.data);

  const signPromise = web3.eth.accounts.signTransaction(tx, PRIVATE_KEY);
  signPromise
    .then((signedTx) => {
      web3.eth.sendSignedTransaction(
        signedTx.rawTransaction,
        function (err, hash) {
          if (!err) {
            console.log(
              "The hash of your transaction is: ",
              hash,
              "\n Check Alchemy's Mempool to view the status of your transaction!"
            );
          } else {
            console.log(
              "Something went wrong during submitting your transaction - ",
              err
            );
          }
        }
      );
    })
    .catch((err) => {
      console.log(" Entire promise has failed - due to ", err);
    });

  // https://gateway.pinata.cloud/ipfs/QmQN1TEMYUGQUbdkhUEquk7qz3AyP2BMiSrxiRDVFdJPqi
}

mintNFT("ipfs://QmQN1TEMYUGQUbdkhUEquk7qz3AyP2BMiSrxiRDVFdJPqi");
